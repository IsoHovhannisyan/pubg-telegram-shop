import React, { useState, useEffect } from "react";
import API from "../api";

const API_URL = process.env.REACT_APP_API_URL;

const categories = [
  "UC_ID",
  "POPULARITY_ID",
  "POPULARITY_HOME",
  "CARS",
  "COSTUMES",
];

const categoryLabels = {
  UC_ID: "ЮС по ID",
  POPULARITY_ID: "Популярность по ID",
  POPULARITY_HOME: "Популярность дома",
  CARS: "Машины",
  COSTUMES: "Одежда / X-костюмы",
};

export default function Products() {
  const [form, setForm] = useState({
    name: "",
    price: "",
    stock: "",
    category: "UC_ID",
    active: true,
    image: null,
  });
  const [products, setProducts] = useState([]);
  const [editingId, setEditingId] = useState(null);

  const token = localStorage.getItem("admin-token");

  const fetchProducts = async () => {
    try {
      const res = await API.get(`${API_URL}/admin/products`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProducts(res.data);
    } catch (err) {
      console.error("❌ Ошибка при получении товаров:", err);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (type === "checkbox") setForm({ ...form, [name]: checked });
    else if (type === "file") setForm({ ...form, image: files[0] });
    else setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      for (let key in form) {
        if (form[key] !== null) formData.append(key, form[key]);
      }
      if (editingId) {
        await API.put(`${API_URL}/admin/products/${editingId}`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
      } else {
        await API.post(`${API_URL}/admin/products`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
      }
      resetForm();
      fetchProducts();
    } catch (err) {
      console.error("❌ Ошибка при сохранении товара:", err);
      alert("Ошибка при сохранении товара");
    }
  };

  const deleteProduct = async (id) => {
    if (!window.confirm("Вы уверены, что хотите удалить этот товар?")) return;
    try {
      await API.delete(`${API_URL}/admin/products/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchProducts();
    } catch (err) {
      console.error("❌ Ошибка при удалении товара:", err);
      alert("Ошибка при удалении");
    }
  };

  const startEdit = (product) => {
    setForm({
      name: product.name,
      price: product.price,
      stock: product.stock,
      category: product.category,
      active: product.active,
      image: null,
    });
    setEditingId(product.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const resetForm = () => {
    setForm({
      name: "",
      price: "",
      stock: "",
      category: "UC_ID",
      active: true,
      image: null,
    });
    setEditingId(null);
  };

  return (
    <div className="p-4 max-w-4xl">
      <h2 className="text-2xl font-bold mb-4">🛒 Управление товарами</h2>

      <form onSubmit={handleSubmit} className="space-y-4 mb-6">
        <div className="grid grid-cols-2 gap-4">
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Название"
            className="input"
            required
          />
          <input
            name="price"
            value={form.price}
            onChange={handleChange}
            placeholder="Цена"
            type="number"
            className="input"
            required
          />
          <input
            name="stock"
            value={form.stock}
            onChange={handleChange}
            placeholder="Количество"
            type="number"
            className="input"
            required
          />
          <select
            name="category"
            value={form.category}
            onChange={handleChange}
            className="input"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {categoryLabels[cat] || cat}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              name="active"
              checked={form.active}
              onChange={handleChange}
            />
            Активен
          </label>

          <input
            type="file"
            name="image"
            accept="image/*"
            onChange={handleChange}
            className="input"
          />
        </div>

        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          {editingId ? "Обновить товар" : "Добавить товар"}
        </button>
      </form>

      <div className="space-y-2">
        {products.map((product) => (
          <div
            key={product.id}
            className="p-3 border rounded flex justify-between items-center"
          >
            <div>
              <div className="font-semibold">{product.name}</div>
              <div className="text-sm text-gray-600">
                {categoryLabels[product.category] || product.category} |{" "}
                {product.price} ₽ | {product.stock} шт
              </div>
              <div
                className={`text-xs mt-1 ${
                  product.active ? "text-green-500" : "text-red-500"
                }`}
              >
                {product.active ? "Активен" : "Неактивен"}
              </div>
              <div className="flex gap-4 mt-2">
                <button
                  onClick={() => startEdit(product)}
                  className="text-blue-600 text-sm underline"
                >
                  Редактировать
                </button>
                <button
                  onClick={() => deleteProduct(product.id)}
                  className="text-red-600 text-sm underline"
                >
                  Удалить
                </button>
              </div>
            </div>
            {product.imageUrl && (
              <img
                src={product.imageUrl}
                alt="cover"
                className="w-12 h-12 object-cover rounded"
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}








