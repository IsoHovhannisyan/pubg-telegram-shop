const db = require('../db/connect');
require('dotenv').config();


const axios = require('axios');
const API_URL = process.env.API_URL || 'http://localhost:3001';

const MANAGER_IDS = process.env.MANAGER_CHAT_ID ? process.env.MANAGER_CHAT_ID.split(',') : [];

function formatItems(items) {
  return items.map(i => `▫️ ${i.title || i.name} x${i.qty} — ${i.price * i.qty} ₽`).join('\n');
}

function getTotal(items) {
  return items.reduce((sum, i) => sum + (i.price * i.qty), 0);
}

function buildManagerMessage(ctx, pubgId, manualItems, autoItems) {
  const userId = ctx.from.id;
  const userTag = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;

  let messageHeader = '🎞️ Новый Смешанный заказ';
  if (manualItems.length > 0 && autoItems.length === 0) messageHeader = '🎞️ Новый Мануальный заказ';
  if (autoItems.length > 0 && manualItems.length === 0) messageHeader = '🎞️ Новый Автоматический заказ';

  let message = `${messageHeader}\n\n`;
  message += `👤 Пользователь: ${userTag} (${userId})\n`;
  message += `🎮 PUBG ID: ${pubgId}\n`;

  if (autoItems.length > 0) {
    message += `\n📦 Автоматические товары:\n${formatItems(autoItems)}\n💰 Сумма: ${getTotal(autoItems)} ₽\n`;
  }

  if (manualItems.length > 0) {
    message += `\n📦 Мануальные товары:\n${formatItems(manualItems)}\n💰 Сумма: ${getTotal(manualItems)} ₽\n`;
  }

  return message;
}

async function registerOrder(ctx, pubgId, items, nickname) {
  const userId = ctx.from.id;
  const createdAt = new Date();

  const manualItems = items.filter(i => i.type === 'manual');
  const autoItems = items.filter(i => i.type === 'auto');

  console.log("🧾 INSERT DATA VIA API:");
  console.log("UserID:", userId);
  console.log("PUBG ID:", pubgId);
  console.log("Nickname:", nickname);
  console.log("Manual Items:", manualItems.length);
  console.log("Auto Items:", autoItems.length);

  if (manualItems.length > 0) {
    await axios.post(`${API_URL}/orders`, {
      user_id: userId,
      pubg_id: pubgId,
      products: manualItems,
      time: createdAt,
      status: 'manual_processing',
      nickname
    });
    console.log('✅ Մանուալ պատվերը ուղարկվեց API-ով');
  }

  if (autoItems.length > 0) {
    await axios.post(`${API_URL}/orders`, {
      user_id: userId,
      pubg_id: pubgId,
      products: autoItems,
      time: createdAt,
      status: 'pending',
      nickname
    });
    console.log('✅ Ավտոմատ պատվերը ուղարկվեց API-ով');
  }

  const message = buildManagerMessage(ctx, pubgId, manualItems, autoItems);
  for (const managerId of MANAGER_IDS) {
    try {
      await ctx.telegram.sendMessage(managerId, message);
    } catch (err) {
      console.error(`❌ Չհաջողվեց ուղարկել մենեջերին (${managerId})`, err.message);
    }
  }

  // 🔁 ԱՅՍՏԵՂ Ավելացվում է processAutoOrder
  if (autoItems.length > 0) {
    setTimeout(async () => {
      try {
        const res = await axios.get(`${API_URL}/orders/user/${ctx.from.id}`);
        const orders = res.data;
        const latestAutoOrder = orders
          .filter(o => o.status === 'pending')
          .sort((a, b) => new Date(b.time) - new Date(a.time))[0];

        if (latestAutoOrder) {
          await processAutoOrder(latestAutoOrder, ctx);
        }
      } catch (err) {
        console.error('❌ Failed to process auto order:', err.message);
      }
    }, 1000);
  }
}

async function processAutoOrder(order) {
  const { id, pubg_id, products, user_id, nickname } = order;
  console.log(`🚀 processAutoOrder() CALLED for order ID ${id}`);

  const ucProducts = products.filter(p => p.category === 'uc_by_id');
  console.log(`🧩 UC Items to redeem:`, ucProducts);
  if (ucProducts.length === 0) {
    console.log(`ℹ️ Order ${id} does not contain uc_by_id items`);
    return;
  }

  try {
    console.log(`📤 Sending redeem request to /activator/redeem`);
    const response = await axios.post(`${API_URL}/activator/redeem`, {
      pubg_id,
      products: ucProducts.map(p => ({ title: p.title, qty: p.qty }))
    });

    console.log('📥 Redeem response:', response.data);

    if (response.data.success && response.data.activated) {
      await axios.patch(`${API_URL}/orders/${id}`, { status: 'delivered' });
      console.log(`✅ Order ${id} успешно активирован и доставлен`);
    } else {
      throw new Error('Activator responded with failure');
    }
  } catch (err) {
    console.error(`❌ Activation failed for order ${id}:`, err.message);

    const message = `⚠️ Не удалось автоматически активировать заказ ID ${id}\n\n👤 Пользователь: ${nickname || '-'} (${user_id})\n🎮 PUBG ID: ${pubg_id}\n\n📦 Товары:\n${ucProducts.map(p => `▫️ ${p.title} x${p.qty}`).join('\n')}`;
    for (const managerId of MANAGER_IDS) {
      try {
        await ctx.telegram.sendMessage(managerId, message);
      } catch (e) {
        console.error(`❌ Can't send fallback to manager ${managerId}:`, e.message);
      }
    }
  }
}


module.exports = registerOrder;





