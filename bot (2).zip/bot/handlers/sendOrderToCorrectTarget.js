const db = require('../db/connect');
const userSelections = require('../utils/userSelections');
const { getPubgNickname } = require('./cart');
const getAvailableProducts = require('../utils/getAvailableProducts');
const generateFreekassaLink = require('../utils/freekassaLink');
const registerOrder = require('./orderHandler');
const getLang = require('../utils/getLang');

async function handleUserIdSubmission(ctx) {
  const lang = await getLang(ctx);
  if (!ctx.message || !ctx.message.text) return;

  const text = ctx.message.text.trim();
  const userId = ctx.from.id;
  const userData = userSelections.get(userId);

  if (!userData) return;

  // ✅ Եթե expectingId false է, բոտը ոչինչ չպետք է անի
  if (!userData.expectingId) return;

  // ✅ Եթե թիվ է, բայց կարճ (ոչ 5-20 նիշ), ասում ենք սխալ է, բայց չմաքրենք expectingId
  if (/^\d+$/.test(text) && (text.length < 5 || text.length > 20)) {
    return ctx.reply(lang.invalid_pubg_id);
  }

  // ❌ Եթե ընդհանրապես ոչ թիվ է (հատուկ նշաններով կամ տառերով), ապա *հասկանանք որ նա չուզեց գրել ID*
  if (!/^[0-9]{5,20}$/.test(text)) {
    delete userData.expectingId;
    userSelections.set(userId, userData);
    return;
  }

  // ✅ nickname ստուգում
  const result = await getPubgNickname(text);
  if (!result.success) {
    return ctx.reply(lang.catalog.nickname_error);
  }

  const nickname = result.nickname;

  try {
    const availableRaw = await getAvailableProducts();
    const availableMap = {};
    for (const id of availableRaw) availableMap[id] = 99;
  } catch (err) {
    console.warn('⚠️ getAvailableProducts fallback');
  }

  // ✅ Պահպանել ID ու nickname
  userData.id = text;
  userData.username = ctx.from.username || null;
  delete userData.expectingId;

  userData.uc = (userData.uc || []).filter(item => item && item.id && item.title && typeof item.price === 'number');
  userData.popularity = (userData.popularity || []).filter(item => item && item.id && item.title && typeof item.price === 'number');
  userSelections.set(userId, userData);

  const prices = {
    "uc_60": 60, "uc_180": 170, "uc_325": 290, "uc_385": 340,
    "uc_660": 580, "uc_720": 630, "uc_985": 870, "uc_1320": 1160,
    "uc_1800": 1550, "uc_1920": 1640, "uc_3850": 3050, "uc_5650": 4600,
    "uc_8100": 6200, "uc_16200": 12200, "uc_24300": 18200, "uc_32400": 24200
  };

  let total = 0;
  const grouped = {};
  const allItems = [
  ...(userData.uc || []),
  ...(userData.popularity || []),
  ...(userData.cars || [])
];

  for (const item of allItems) {
    const id = item.id;
    if (!grouped[id]) grouped[id] = { ...item };
    else grouped[id].qty += item.qty;
  }

  const productList = Object.values(grouped).map(i => {
    const title = i.name || i.title || 'Неизвестный товар';
    const price = prices[i.value || i.id] || i.price || 0;
    const sum = price * i.qty;
    total += sum;
    return `📦 ${title} x${i.qty} — ${sum} ${lang.currency}`;
  }).join('\n');

  const hasManual = allItems.some(p => p.type === 'manual');
  const hasAutoOnly = allItems.every(p => p.type === 'auto');

  await ctx.reply(`🛒 Ваш заказ регистрирован!\n\n🎮 PUBG ID: ${text}\n👤 Ник: ${nickname}\n${productList}\n\n💰 Общая сумма: ${total}${lang.currency}`);

  try {
    const groupedItems = Object.values(grouped);
    await registerOrder(ctx, text, groupedItems, nickname);


    if (hasManual) {
      await ctx.reply(`🧾 Ваш заказ передан администратору.\n\n⏳ Ожидайте, с вами свяжется оператор.`);
    }

    if (hasAutoOnly) {
      const paymentLink = generateFreekassaLink(ctx.from.id, total);
      await ctx.reply(`💳 Для завершения заказа, пожалуйста, оплатите по ссылке:\n\n🔗 ${paymentLink}\n\n⏳ После успешной оплаты заказ будет подтверждён автоматически.`);
    }

    userSelections.delete(userId);
  } catch (err) {
    console.error("❌ Պատվերի գրանցման սխալ:", err.message);
  }
}

module.exports = {
  handleUserIdSubmission
};

