// ===============================
// ✅ 4. catalog.js (լիարժեք տարբերակ՝ UC по входу / по ID բաժանումով)
// ===============================

const { Markup } = require('telegraf');
const db = require('../db/connect');
require('dotenv').config();

const userSelections = require('../utils/userSelections');
const { getPubgNickname } = require('./cart');
const registerOrder = require('./orderHandler');
const getAvailableProducts = require('../utils/getAvailableProducts');
const checkUCQuantities = require('../utils/checkUCQuantities');
const generateFreekassaLink = require('../utils/freekassaLink');

async function getLang(ctx) {
  const res = await db.query('SELECT language FROM users WHERE telegram_id = $1', [ctx.from.id]);
  const langCode = res.rows[0]?.language || 'ru';
  return require(`../../lang/${langCode}`);
}

const ucPackages = [
  { name: "60 UC", value: "uc_60" }, { name: "180 UC", value: "uc_180" },
  { name: "325 UC", value: "uc_325" }, { name: "385 UC", value: "uc_385" },
  { name: "660 UC", value: "uc_660" }, { name: "720 UC", value: "uc_720" },
  { name: "985 UC", value: "uc_985" }, { name: "1320 UC", value: "uc_1320" },
  { name: "1800 UC", value: "uc_1800" }, { name: "1920 UC", value: "uc_1920" },
  { name: "3850 UC", value: "uc_3850" }, { name: "5650 UC", value: "uc_5650" },
  { name: "8100 UC", value: "uc_8100" }, { name: "16200 UC", value: "uc_16200" },
  { name: "24300 UC", value: "uc_24300" }, { name: "uc_32400", value: "uc_32400" }
];

const manualUC = ['uc_1320', 'uc_1920', 'uc_24300'];
function getUCType(id) {
  return manualUC.includes(id) ? 'manual' : 'auto';
}

function buildCatalogKeyboard(lang, filteredList) {
  const rows = [];
  for (let i = 0; i < filteredList.length; i += 2) {
    const row = [];
    row.push(Markup.button.callback(filteredList[i].name, filteredList[i].value));
    if (filteredList[i + 1]) {
      row.push(Markup.button.callback(filteredList[i + 1].name, filteredList[i + 1].value));
    }
    rows.push(row);
  }
  rows.push([Markup.button.callback(lang.buttons.to_cart, "go_to_cart")]);
  return rows;
}

const catalogCommand = async (ctx, type = 'auto') => {
  const lang = await getLang(ctx);
  const filtered = ucPackages.filter(p => getUCType(p.value) === type);
  const buttons = buildCatalogKeyboard(lang, filtered);
  const title = type === 'manual' ? lang.catalog.select_uc_manual : lang.catalog.select_uc;
  await ctx.reply(title, Markup.inlineKeyboard(buttons));
};

const callbackQuery = async (ctx) => {
  const prices = {
    "uc_60": 60, "uc_180": 170, "uc_325": 290, "uc_385": 340,
    "uc_660": 580, "uc_720": 630, "uc_985": 870, "uc_1320": 1160,
    "uc_1800": 1550, "uc_1920": 1640, "uc_3850": 3050, "uc_5650": 4600,
    "uc_8100": 6200, "uc_16200": 12200, "uc_24300": 18200, "uc_32400": 24200
  };

  const lang = await getLang(ctx);
  const selected = ctx.callbackQuery.data;

  if (selected === 'go_to_cart') {
    return require('./cart').showCart(ctx);
  }

  const validKeys = Object.keys(prices);
  if (!validKeys.includes(selected)) {
    return ctx.answerCbQuery(lang.unknown_action || "❌ Սխալ կամ անթույլատրելի ընտրություն", { show_alert: true });
  }

  await ctx.answerCbQuery();

  const packageData = ucPackages.find(p => p.value === selected);
  if (!packageData) return ctx.answerCbQuery(lang.unknown_action);

  const userId = ctx.from.id;
  let userData = userSelections.get(userId) || { uc: [], id: null };
  if (!userData.uc) userData.uc = [];

  const existing = userData.uc.find(p => p.id === packageData.value);
  const type = getUCType(packageData.value);

  if (existing) {
    existing.qty += 1;
  } else {
    userData.uc.push({
      
      id: parseInt(packageData.value.replace('uc_', '')),
      title: packageData.name,
      price: prices[packageData.value] || 0,
      type,
      qty: 1
    });
  }

  userSelections.set(userId, userData);
  await ctx.reply(
    `${packageData.name} ✅ ${lang.catalog.added}`,
    Markup.inlineKeyboard([
      [Markup.button.callback(lang.buttons.to_cart, "go_to_cart")]
    ])
  );
};

module.exports = catalogCommand;
module.exports.callbackQuery = callbackQuery;
module.exports.catalogCommand = catalogCommand;















