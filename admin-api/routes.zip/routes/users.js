const express = require('express');
const router = express.Router();
const db = require('../../bot/db/connect');

router.get('/:telegram_id', async (req, res) => {
  const { telegram_id } = req.params;

  try {
    const result = await db.query('SELECT language FROM users WHERE telegram_id = $1', [telegram_id]);
    const language = result.rows[0]?.language || 'ru';
    res.json({ language });
  } catch (err) {
    console.error('❌ User fetch error:', err.message);
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;