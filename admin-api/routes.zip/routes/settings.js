const express = require("express");
const fs = require("fs");
const router = express.Router();
const verifyToken = require("./verifyToken");

const FILE_PATH = "./admin-api/shopStatus.json";

// GET current status
router.get("/shop-status", verifyToken, (req, res) => {
  try {
    const data = JSON.parse(fs.readFileSync(FILE_PATH, "utf-8"));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Не удалось получить статус" });
  }
});

// POST update status
router.post("/shop-status", verifyToken, (req, res) => {
  const { shopOpen } = req.body;
  try {
    fs.writeFileSync(FILE_PATH, JSON.stringify({ shopOpen }));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Не удалось сохранить" });
  }
});

module.exports = router;
