// admin-api/routes/adminAuth.js

const express = require('express');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const router = express.Router();

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // ✅ ԱՅՍՏԵՂ ԴԻՐ debug log-երը
    console.log("✅ ADMIN_USERNAME:", process.env.ADMIN_USERNAME);
    console.log("✅ ADMIN_PASSWORD:", process.env.ADMIN_PASSWORD);
    console.log("✅ JWT_SECRET:", process.env.JWT_SECRET);

    if (
      username !== process.env.ADMIN_USERNAME ||
      password !== process.env.ADMIN_PASSWORD
    ) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ role: 'admin' }, process.env.JWT_SECRET, {
      expiresIn: '2h'
    });

    res.json({ token });
  } catch (err) {
    console.error('❌ Login error:', err.message);
    res.status(500).json({ error: 'Login failed' });
  }
});

module.exports = router;


