// createShopStatusIfMissing.js
const fs = require("fs");
const path = require("path");

const FILE_PATH = path.join(__dirname, "../shopStatus.json");

if (!fs.existsSync(FILE_PATH)) {
  fs.writeFileSync(FILE_PATH, JSON.stringify({ shopOpen: true }, null, 2));
  console.log("✅ Created default shopStatus.json");
}
