const getAvailableProducts = require('../utils/getAvailableProducts');
const getPubgNickname = require('./cart').getPubgNickname;
const userSelections = require('../utils/userSelections');
const sendOrderToCorrectTarget = require('./sendOrderToCorrectTarget');
const generateFreekassaLink = require('../utils/freekassaLink');
const getLang = require('../utils/getLang');

const messageHandler = async (ctx) => {
  const lang = await getLang(ctx);
  const text = ctx.message.text.trim();
  const userId = ctx.from.id;
  const userData = userSelections.get(userId);
  if (!userData || !userData.expectingId) return;

  // ✅ Ստուգում ենք ID
  if (!/^[0-9]{5,20}$/.test(text)) {
    return ctx.reply(lang.invalid_pubg_id);
  }

  const result = await getPubgNickname(text);
  if (!result.success) {
    return ctx.reply(lang.catalog.nickname_error);
  }

  const nickname = result.nickname;
  let availableMap = {};
  try {
    const availableRaw = await getAvailableProducts();
    for (const id of availableRaw) availableMap[id] = 99;
  } catch (err) {
    console.warn('⚠️ getAvailableProducts fallback');
  }

  userData.id = text;
  userData.username = ctx.from.username || null;
  delete userData.expectingId;

  userData.uc = (userData.uc || []).filter(item =>
    item && item.id && item.title && typeof item.price === 'number'
  );
  userData.popularity = (userData.popularity || []).filter(item =>
    item && item.id && item.title && typeof item.price === 'number'
  );
  userSelections.set(userId, userData);

  const prices = {
    "uc_60": 60, "uc_180": 170, "uc_325": 290, "uc_385": 340,
    "uc_660": 580, "uc_720": 630, "uc_985": 870, "uc_1320": 1160,
    "uc_1800": 1550, "uc_1920": 1640, "uc_3850": 3050, "uc_5650": 4600,
    "uc_8100": 6200, "uc_16200": 12200, "uc_24300": 18200, "uc_32400": 24200
  };

  let total = 0;
  const grouped = {};
  const allItems = [...(userData.uc || []), ...(userData.popularity || [])];

  for (const item of allItems) {
    const id = item.id;
    if (!grouped[id]) {
      grouped[id] = { ...item };
    } else {
      grouped[id].qty += item.qty;
    }
  }

  const groupedItems = Object.values(grouped);

  const productList = groupedItems.map(i => {
    const title = i.name || i.title || 'Անհայտ ապրանք';
    const price = prices[i.value || i.id] || i.price || 0;
    const sum = price * i.qty;
    total += sum;
    return `📦 ${title} x${i.qty} — ${sum} ${lang.currency}`;
  }).join('\n');

  const hasManual = groupedItems.some(p => p.type === 'manual');
  const hasAutoOnly = groupedItems.every(p => p.type === 'auto');

  await ctx.reply(`🛒 Ваш заказ зарегистрирован!\n\n🎮 PUBG ID: ${text}\n👤 Ник: ${nickname}\n${productList}\n\n💰 Общая сумма: ${total}₽`);

  try {
    await sendOrderToCorrectTarget(ctx, text, groupedItems);

    if (hasManual) {
      await ctx.reply(`🧾 Ваш заказ передан администратору.\n\n⏳ Ожидайте, с вами свяжется оператор для завершения покупки.`);
    }

    if (hasAutoOnly) {
      const paymentLink = generateFreekassaLink(ctx.from.id, total);
      await ctx.reply(`💳 Для завершения заказа, пожалуйста, оплатите по ссылке:\n\n🔗 ${paymentLink}\n\n⏳ После успешной оплаты заказ будет подтверждён автоматически.`);
    }

    userSelections.delete(userId);
  } catch (err) {
    console.error("❌ Պատվերի գրանցման սխալ:", err.message);
  }
};

module.exports = messageHandler;
