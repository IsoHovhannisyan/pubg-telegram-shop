// ✅ handlers/catalogManual.js
const { catalogCommand } = require('./catalog');

module.exports = async (ctx) => {
  await catalogCommand(ctx, 'manual');
};