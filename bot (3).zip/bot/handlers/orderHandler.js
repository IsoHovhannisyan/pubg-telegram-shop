const db = require('../db/connect');
require('dotenv').config();

const MANAGER_IDS = process.env.MANAGER_CHAT_ID ? process.env.MANAGER_CHAT_ID.split(',') : [];

function formatItems(items) {
  return items.map(i => `▫️ ${i.title || i.name} x${i.qty} — ${i.price * i.qty} ₽`).join('\n');
}

function getTotal(items) {
  return items.reduce((sum, i) => sum + (i.price * i.qty), 0);
}

function buildManagerMessage(ctx, pubgId, manualItems, autoItems) {
  const userId = ctx.from.id;
  const userTag = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;

  let messageHeader = '🎞️ Новый Смешанный заказ';
  if (manualItems.length > 0 && autoItems.length === 0) messageHeader = '🎞️ Новый Мануальный заказ';
  if (autoItems.length > 0 && manualItems.length === 0) messageHeader = '🎞️ Новый Автоматический заказ';

  let message = `${messageHeader}\n\n`;
  message += `👤 Пользователь: ${userTag} (${userId})\n`;
  message += `🎮 PUBG ID: ${pubgId}\n`;

  if (autoItems.length > 0) {
    message += `\n📦 Автоматические товары:\n${formatItems(autoItems)}\n💰 Сумма: ${getTotal(autoItems)} ₽\n`;
  }

  if (manualItems.length > 0) {
    message += `\n📦 Мануальные товары:\n${formatItems(manualItems)}\n💰 Сумма: ${getTotal(manualItems)} ₽\n`;
  }

  return message;
}

async function getProductCategories(items) {
  const ids = items
    .map(i => parseInt(i.id))
    .filter(id => !isNaN(id));

  if (ids.length === 0) return items;

  const placeholders = ids.map((_, i) => `$${i + 1}`).join(',');
  const res = await db.query(
    `SELECT id, category FROM products WHERE id IN (${placeholders})`,
    ids
  );

  const categoryMap = {};
  res.rows.forEach(row => {
    categoryMap[row.id] = row.category;
  });

  return items.map(i => {
    const parsedId = parseInt(i.id);
    return {
      ...i,
      category: !isNaN(parsedId) ? (categoryMap[parsedId] || 'Без категории') : 'Без категории'
    };
  });
}

async function registerOrder(ctx, pubgId, items, nickname) {
  
  const userId = ctx.from.id;
  const createdAt = new Date();

  const manualItems = await getProductCategories(
    items.filter(i => i.type === 'manual')
  );

  const autoItems = await getProductCategories(
    items.filter(i => i.type === 'auto')
  );

  console.log("🧾 INSERT DATA:");
console.log("UserID:", ctx.from.id);
console.log("PUBG ID:", pubgId);
console.log("Nickname:", nickname);
console.log("Manual Items:", manualItems.length);
console.log("Auto Items:", autoItems.length);

  if (manualItems.length > 0) {
    await db.query(
      `INSERT INTO orders (user_id, pubg_id, products, time, status, nickname)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, pubgId, JSON.stringify(manualItems), createdAt, 'manual_processing', nickname]
    );
    console.log('✅ Մանուալ պատվերը գրանցված է');
  }

  if (autoItems.length > 0) {
    await db.query(
      `INSERT INTO orders (user_id, pubg_id, products, time, status, nickname)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, pubgId, JSON.stringify(autoItems), createdAt, 'pending', nickname]
    );
    console.log('✅ Ավտոմատ պատվերը գրանցված է');
  }

  const message = buildManagerMessage(ctx, pubgId, manualItems, autoItems);
  for (const managerId of MANAGER_IDS) {
    try {
      await ctx.telegram.sendMessage(managerId, message);
    } catch (err) {
      console.error(`❌ Չհաջողվեց ուղարկել մենեջերին (${managerId})`, err.message);
    }
  }
}

module.exports = registerOrder;





